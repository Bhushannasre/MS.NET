using Catalog;
namespace ShoppingCart{

    public class Item{
        public Product? TheProduct{get;set;}
        public int Quantity{get;set;}

    }
}